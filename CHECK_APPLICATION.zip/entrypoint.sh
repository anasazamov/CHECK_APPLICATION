#!/bin/sh

if [ ! -f .env ]; then
    echo "Creating the .env file..."
    echo "DB_NAME=cradle" >> .env
    echo "DB_ADMIN=cradle" >> .env
    echo "DB_PWD=cradle" >> .env
    echo "SECRET_KEY=cradle" >> .env
    echo "DB_PORT=5432" >> .env
    echo "TELEGRAM_BOT_TOKEN=7846581361:AAHWEXIAr0-BFfUrYHSjFzWLLRZOIi6CNvo" >> .env
fi

echo "Applying database migrations..."
python manage.py migrate

echo "Creating default superuser..."
python manage.py shell <<EOF
from django.contrib.auth import get_user_model
from check_server.models import Company
User = get_user_model()
if not User.objects.filter(username="admin").exists():
    user = User.objects.create_superuser(
        username="admin",
        email="admin@admin.com",
        password="admin"
    )
    print("Superuser created.")
else:
    user = User.objects.filter(username="admin").first()
    if not Company.objects.filter(name="Cradle", user=user).exists():
        company = Company.objects.create(name="Cradle Vision")
        company.user.add(user)
    print("Superuser already exists.")
EOF

echo "Starting Django server..."
exec "$@"
